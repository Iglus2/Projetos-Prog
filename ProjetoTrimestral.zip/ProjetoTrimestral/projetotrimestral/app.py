from wtforms.validators import DataRequired

app = Flask(__name__)

app.config["SECRET_KEY"] = "1234"


class EfetuarLogin(FlaskForm):
    nome = StringField("Nome:", validators=DataRequired(message="É necessário "))
